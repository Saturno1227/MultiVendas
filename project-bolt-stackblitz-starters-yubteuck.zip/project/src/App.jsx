import React from 'react';
import { FiSearch } from 'react-icons/fi';
import { FaArrowRight, FaFacebookF, FaTwitter, FaYoutube, FaInstagram, FaStar } from 'react-icons/fa';
import { MdClose } from 'react-icons/md';

function App() {
  const categories = [
    {
      title: 'Restaurante',
      image: 'https://static.ifood-static.com.br/image/upload/t_high/discoveries/Restaurante_2x_ki4liz.png',
      bgColor: 'bg-red-500',
      action: 'Ver opções'
    },
    {
      title: 'Mercado',
      image: 'https://static.ifood-static.com.br/image/upload/t_high/discoveries/Mercado_2x_cyqbge.png',
      bgColor: 'bg-lime-500',
      action: 'Buscar lojas'
    }
  ];

  const miniCategories = [
    {
      title: 'Bebidas',
      image: 'https://static.ifood-static.com.br/image/upload/t_high/discoveries/Bebidas_2x_JqT5nn.png',
      bgColor: 'bg-yellow-400'
    },
    {
      title: 'Farmácia',
      image: 'https://static.ifood-static.com.br/image/upload/t_high/discoveries/Farmacia_2x_v3hen3.png',
      bgColor: 'bg-pink-400'
    },
    {
      title: 'Pet shop',
      image: 'https://static.ifood-static.com.br/image/upload/t_high/discoveries/Petshop_2x_cvoQhk.png',
      bgColor: 'bg-purple-400'
    }
  ];

  const restaurants = [
    {
      name: "McDonald's",
      category: "Lanches",
      logo: "https://static.ifood-static.com.br/image/upload/t_thumbnail/logosgde/201910292243_94aaf166-84cc-4ebf-a35d-d223be34d01f.png"
    },
    {
      name: "Coco Bambu",
      category: "Frutos Do Mar",
      logo: "https://static.ifood-static.com.br/image/upload/t_thumbnail/logosgde/coco.png"
    },
    {
      name: "China in Box",
      category: "Chinesa",
      logo: "https://static.ifood-static.com.br/image/upload/t_thumbnail/logosgde/chinainbox.png"
    },
    {
      name: "Habib's",
      category: "Lanches",
      logo: "https://static.ifood-static.com.br/image/upload/t_thumbnail/logosgde/habibs.png"
    },
    {
      name: "Outback Steakhouse",
      category: "Lanches",
      logo: "https://static.ifood-static.com.br/image/upload/t_thumbnail/logosgde/outback.png"
    }
  ];

  const promotions = [
    {
      title: "Almoço a partir de R$10",
      image: "https://static.ifood-static.com.br/image/upload/t_high/discoveries/Almoco10_2x_yqcyqk.jpg",
      bgColor: "bg-yellow-400"
    },
    {
      title: "Pratos com até 70% OFF",
      image: "https://static.ifood-static.com.br/image/upload/t_high/discoveries/70OFF_2x_yqcyqk.jpg",
      bgColor: "bg-red-500"
    },
    {
      title: "Super Restaurantes",
      image: "https://static.ifood-static.com.br/image/upload/t_high/discoveries/SuperRestaurantes_2x_yqcyqk.jpg",
      bgColor: "bg-red-500"
    }
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Navigation */}
      <nav className="flex items-center justify-between px-6 py-4 bg-white border-b">
        <img src="https://www.ifood.com.br/static/images/logo-ifood-4.png" alt="iFood" className="h-8" />
        
        <div className="flex items-center space-x-6">
          <a href="#" className="text-gray-600 hover:text-gray-900">Entregador</a>
          <a href="#" className="text-gray-600 hover:text-gray-900">Restaurante e Mercado</a>
          <a href="#" className="text-gray-600 hover:text-gray-900">Carreiras</a>
          <a href="#" className="text-gray-600 hover:text-gray-900">iFood Card</a>
          <a href="#" className="text-gray-600 hover:text-gray-900">Para Empresas</a>
        </div>

        <div className="flex items-center space-x-4">
          <a href="#" className="text-red-500 hover:text-red-600">criar conta</a>
          <button className="bg-red-500 text-white px-6 py-2 rounded hover:bg-red-600">
            Entrar
          </button>
        </div>
      </nav>

      {/* Main Content */}
      <main className="max-w-6xl mx-auto px-6 py-8">
        {/* Search Bar */}
        <div className="max-w-2xl mx-auto flex mb-12">
          <div className="flex-1 relative">
            <FiSearch className="absolute left-4 top-1/2 transform -translate-y-1/2 text-gray-400" />
            <input
              type="text"
              placeholder="Em qual endereço você está?"
              className="w-full pl-12 pr-4 py-4 border rounded-l bg-white focus:outline-none focus:ring-2 focus:ring-red-500"
            />
          </div>
          <button className="bg-red-500 text-white px-8 py-4 rounded-r hover:bg-red-600">
            Buscar
          </button>
        </div>

        {/* Main Categories */}
        <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-12">
          {categories.map((category) => (
            <div key={category.title} className={`${category.bgColor} rounded-lg p-6 text-white relative overflow-hidden`}>
              <div className="flex justify-between items-start">
                <div>
                  <h2 className="text-3xl font-bold mb-4">{category.title}</h2>
                  <button className="bg-white/20 hover:bg-white/30 text-white px-4 py-2 rounded-full flex items-center gap-2">
                    {category.action}
                    <FaArrowRight />
                  </button>
                </div>
                <img src={category.image} alt={category.title} className="w-40 h-40 object-contain" />
              </div>
            </div>
          ))}
        </div>

        {/* Mini Categories */}
        <div className="grid grid-cols-3 gap-6 mb-16">
          {miniCategories.map((category) => (
            <div key={category.title} className={`${category.bgColor} rounded-lg p-4 text-white relative overflow-hidden`}>
              <div className="flex justify-between items-center">
                <h3 className="text-xl font-semibold">{category.title}</h3>
                <img src={category.image} alt={category.title} className="w-20 h-20 object-contain" />
              </div>
            </div>
          ))}
        </div>

        {/* Restaurants Section */}
        <section className="mb-16">
          <h2 className="text-2xl font-bold mb-6">Os melhores restaurantes</h2>
          <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
            {restaurants.map((restaurant) => (
              <div key={restaurant.name} className="bg-white rounded-lg overflow-hidden shadow hover:shadow-md transition-shadow">
                <div className="relative">
                  <div className="absolute top-2 right-2 bg-white rounded-full p-1">
                    <MdClose className="text-gray-400 hover:text-gray-600 cursor-pointer" />
                  </div>
                </div>
                <div className="p-4">
                  <img src={restaurant.logo} alt={restaurant.name} className="w-16 h-16 object-contain mb-3" />
                  <h3 className="font-medium text-gray-900">{restaurant.name}</h3>
                  <p className="text-sm text-gray-500">{restaurant.category}</p>
                  <div className="flex items-center mt-2">
                    <FaStar className="text-yellow-400" />
                    <span className="text-sm text-gray-600 ml-1">4.5</span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Promotional Banners */}
        <section className="mb-16">
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            {promotions.map((promo) => (
              <div key={promo.title} className="relative overflow-hidden rounded-lg cursor-pointer">
                <div className="absolute inset-0 bg-gradient-to-t from-black/50 to-transparent" />
                <img src={promo.image} alt={promo.title} className="w-full h-48 object-cover" />
                <div className="absolute bottom-0 left-0 p-4">
                  <div className="bg-green-600 text-white text-sm px-2 py-1 rounded inline-block mb-2">
                    Entrega Grátis
                  </div>
                  <h3 className="text-white text-xl font-bold">{promo.title}</h3>
                </div>
              </div>
            ))}
          </div>
        </section>

        {/* Benefits Banner */}
        <section className="mb-16">
          <div className="bg-gradient-to-r from-red-700 to-purple-900 rounded-lg overflow-hidden">
            <div className="flex items-center justify-between p-8">
              <div className="flex items-center space-x-4">
                <img src="https://www.ifood.com.br/static/images/logo-ifood-4.png" alt="iFood" className="h-8" />
                <span className="text-2xl font-bold text-white">Benefícios</span>
              </div>
              <div className="flex items-center">
                <img src="https://www.ifood.com.br/static/images/credit-card.png" alt="iFood Card" className="h-12" />
                <div className="ml-4 text-white">
                  <h3 className="text-lg font-semibold">O vale-alimentação do iFood</h3>
                  <p>taxa zero para a sua empresa</p>
                </div>
              </div>
            </div>
          </div>
        </section>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t">
        <div className="max-w-6xl mx-auto px-6 py-12">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8 mb-12">
            <div>
              <h4 className="font-bold text-gray-900 mb-4">iFood</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-600 hover:text-gray-900">Site Institucional</a></li>
                <li><a href="#" className="text-gray-600 hover:text-gray-900">Fale Conosco</a></li>
                <li><a href="#" className="text-gray-600 hover:text-gray-900">Conta e Segurança</a></li>
                <li><a href="#" className="text-gray-600 hover:text-gray-900">Carreiras</a></li>
                <li><a href="#" className="text-gray-600 hover:text-gray-900">Entregadores</a></li>
              </ul>
            </div>
            
            <div>
              <h4 className="font-bold text-gray-900 mb-4">Descubra</h4>
              <ul className="space-y-2">
                <li><a href="#" className="text-gray-600 hover:text-gray-900">Cadastre seu Restaurante ou Mercado</a></li>
                <li><a href="#" className="text-gray-600 hover:text-gray-900">iFood Shop</a></li>
                <li><a href="#" className="text-gray-600 hover:text-gray-900">iFood Empresas</a></li>
                <li><a href="#" className="text-gray-600 hover:text-gray-900">Blog iFood Empresas</a></li>
              </ul>
            </div>

            <div>
              <h4 className="font-bold text-gray-900 mb-4">Social</h4>
              <div className="flex space-x-4">
                <a href="#" className="text-gray-600 hover:text-gray-900"><FaFacebookF /></a>
                <a href="#" className="text-gray-600 hover:text-gray-900"><FaTwitter /></a>
                <a href="#" className="text-gray-600 hover:text-gray-900"><FaYoutube /></a>
                <a href="#" className="text-gray-600 hover:text-gray-900"><FaInstagram /></a>
              </div>
            </div>
          </div>

          <div className="border-t pt-8">
            <div className="flex flex-col md:flex-row justify-between items-center">
              <div className="mb-4 md:mb-0">
                <img src="https://www.ifood.com.br/static/images/logo-ifood-4.png" alt="iFood" className="h-8" />
              </div>
              <div className="text-sm text-gray-600">
                <p>© Copyright 2021 - iFood - Todos os direitos reservados iFood.com Agência de Restaurantes Online S.A.</p>
                <p>CNPJ 14.380.200/0001-21 / Avenida dos Autonomistas, nº 1496, Vila Yara, Osasco/SP - CEP 06.020-902</p>
              </div>
            </div>
            <div className="flex flex-wrap justify-center md:justify-end gap-4 mt-4">
              <a href="#" className="text-gray-600 hover:text-gray-900">Termos e condições de uso</a>
              <a href="#" className="text-gray-600 hover:text-gray-900">Código de conduta</a>
              <a href="#" className="text-gray-600 hover:text-gray-900">Privacidade</a>
              <a href="#" className="text-gray-600 hover:text-gray-900">Dicas de segurança</a>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}

export default App;